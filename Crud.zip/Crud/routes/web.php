<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('phonebook/index');
// });

Route::get('/', [
    'uses' => 'Home@home',
    'as' => 'home'
]);

Route::get('/delete/{id}', [
    'uses' => 'Home@delete',
    'as' => 'delete'
]);

Route::get('/edit/{id}', [
    'uses' => 'Home@edit',
    'as' => 'edit'
]);

Route::post('/save/{id}', [
    'uses' => 'Home@save',
    'as' => 'save'
]);

Route::get('/add', [
    'uses' => 'Add@new_contact',
    'as' => 'add'
]);

Route::post('/create', [
    'uses' => 'Add@create_new_contact',
    'as' => 'create'
]);
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
