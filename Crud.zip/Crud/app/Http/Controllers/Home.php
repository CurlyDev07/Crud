<?php

namespace App\Http\Controllers;
use Session;
use Illuminate\Http\Request;
use App\Phonebook;

class Home extends Controller
{
    public function home(){
        $phonebooks = Phonebook::all();

        return view('/phonebook/index')->with('phonebooks', $phonebooks);
    }//read

    public function delete($id){
        $phonebook = Phonebook::find($id);
        $phonebook->delete();

        Session::flash('deleted', 'Contact was deleted');
        return redirect()->back();
    }//delete

    public function edit($id){
        $phonebook = Phonebook::find($id);
       
        return view('/phonebook/edit')->with('phonebook', $phonebook);
    }

   public function save(Request $request ,$id){
        $request->validate([
            'full_name' => 'required'
        ]);

        $phonebook = Phonebook::find($id);
        $phonebook->full_name = $request->full_name;
        $phonebook->address = $request->address;
        $phonebook->contact_number = $request->contact_number;
        $phonebook->email_address = $request->email;
       
        $phonebook->save();
        Session::flash('updated', 'Contact was updated');
        return redirect('/');
   }
}
