<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Phonebook;
use Session;
class Add extends Controller
{
    public function new_contact(){
        return view('/phonebook/add');
    }

    public function create_new_contact(Request $request){
        
        $addContact = new Phonebook;
        $addContact->full_name = $request->full_name;
        $addContact->address = $request->address;
        $addContact->contact_number = $request->contact_number;
        $addContact->email_address = $request->email;
      
        $addContact->save();
        Session::flash('success', 'New contact added');
        return redirect('/');
    }
    
}
