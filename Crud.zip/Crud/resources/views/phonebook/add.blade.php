@extends('layout/layout')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="container border">
                <form action="{{ 'create' }}" method="post">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="full_name" class="form-control-label">Full name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="address" class="form-control-label">Address</label>
                                <input type="text" class="form-control" id="address" name="address">
                            </div>
                        </div>
                    </div><!--row-->

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="contact_number" class="form-control-label">Contact number</label>
                                <input type="text" class="form-control" id="contact_number" name="contact_number">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="email" class="form-control-label">Email</label>
                                <input type="text" class="form-control" id="email" name="email">
                            </div>
                        </div>
                    </div><!--row-->
                        
                    <input type="submit" value="Add new contact" class="btn btn-success mb-3">

                </form><!-- form -->
            </div><!-- container -->
        </div><!-- col-sm-12 -->
    </div><!-- row -->
</div>
@endsection