@extends('layout/layout')

@section('content')
<div class="container">

    

    <div class="row">
        <div class="col-sm-12">
            <table class="table-striped table-condensed table-bordered text-center col-sm-12">
                <tr>
                    <th>#</th>
                    <th>Full name</th>
                    <th>address</th>
                    <th>Contact number</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            
            @foreach ($phonebooks as $phonebook)
                <tr>
                    <th>{{ $phonebook->id }}</th>
                    <th>{{ $phonebook->full_name }}</th>
                    <th>{{ $phonebook->address }}</th>
                    <th>{{ $phonebook->contact_number }}</th>
                    <th>{{ $phonebook->email_address }}</th>
                    <th>
                        <a href="{{ route('edit', ['id' => $phonebook->id]) }}" class="btn btn-success">Edit</a>
                        <a href="{{ route('delete', ['id' => $phonebook->id]) }}" class="btn btn-danger">Delete</a>

                    </th>
                </tr>
            @endforeach
            </table>
        </div>
    </div>

</div><!-- container -->
@endsection