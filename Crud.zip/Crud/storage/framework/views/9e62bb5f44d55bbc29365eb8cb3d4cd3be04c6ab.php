<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="container border">
                <form action="<?php echo e(route('save', ['id' => $phonebook->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="full_name" class="form-control-label">Full name</label>
                                <input type="text" class="form-control" id="full_name" value="<?php echo e($phonebook->full_name); ?>" name="full_name">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="address" class="form-control-label">Address</label>
                                <input type="text" class="form-control" id="address" value="<?php echo e($phonebook->address); ?>" name="address">
                            </div>
                        </div>
                    </div><!--row-->

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="contact_number" class="form-control-label">Contact number</label>
                                <input type="text" class="form-control" id="contact_number" value="<?php echo e($phonebook->contact_number); ?>" name="contact_number">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="email" class="form-control-label">Email</label>
                                <input type="text" class="form-control" id="email" value="<?php echo e($phonebook->email_address); ?>" name="email">
                            </div>
                        </div>
                    </div><!--row-->
                        
                    <input type="submit" value="Edit contact" class="btn btn-success mb-3">

                </form><!-- form -->
            </div><!-- container -->
        </div><!-- col-sm-12 -->
    </div><!-- row -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>