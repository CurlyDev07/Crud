<?php $__env->startSection('content'); ?>
<div class="container">

    

    <div class="row">
        <div class="col-sm-12">
            <table class="table-striped table-condensed table-bordered text-center col-sm-12">
                <tr>
                    <th>#</th>
                    <th>Full name</th>
                    <th>address</th>
                    <th>Contact number</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            
            <?php $__currentLoopData = $phonebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phonebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($phonebook->id); ?></th>
                    <th><?php echo e($phonebook->full_name); ?></th>
                    <th><?php echo e($phonebook->address); ?></th>
                    <th><?php echo e($phonebook->contact_number); ?></th>
                    <th><?php echo e($phonebook->email_address); ?></th>
                    <th>
                        <a href="<?php echo e(route('edit', ['id' => $phonebook->id])); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(route('delete', ['id' => $phonebook->id])); ?>" class="btn btn-danger">Delete</a>

                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

</div><!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>