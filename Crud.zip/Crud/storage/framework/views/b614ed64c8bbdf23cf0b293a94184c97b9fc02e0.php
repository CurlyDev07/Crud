<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="navbar navbar-expand navbar-dark bg-dark">
        <div class="navbar-brand">Phonebook</div>
        <div class="navbar-nav ml-auto">
           <a href="<?php echo e(returnview('/phonebook/index')); ?>" class="nav-item nav-link text-light">Home</a>
        </div>
    </div>

</div><!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>